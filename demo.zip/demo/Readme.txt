Requisition:
-Java
-Maven
-Mysql
-Docker

Start and Run the Application:
1) Open terminal in project directory "demo\demo>", run "mvn clean install".
2) Go to directory "demo\demo\docker>", run "docker-compose up".
3) Use any to tool to rest call the API. Example : "curl http://localhost:8080/task/List"