package com.example.demo.controller;

import com.example.demo.model.Task;
import com.example.demo.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/task")
public class TaskController {
    @Autowired
    TaskService taskService;

    @GetMapping("/List")
    public List<Task> list() {
        return taskService.listAllTask();
    }
    @PostMapping("/Add")
    public void add(@RequestBody Task task) {
    	taskService.saveTask(task);
    }
    @PutMapping("/Mark-complete")
    public void update() {
    	taskService.markComplete();
    }
    @DeleteMapping("/Delete")
    public void delete() {
    	taskService.deleteTask();
    }
}