package com.example.demo.model;

import javax.persistence.*;

import org.hibernate.annotations.Type;
@Entity
@Table(name = "task")
public class Task {
    private int Id;
    private String Title;
    private String Description;
    
//    @Column(name = "IsDone",columnDefinition = "TINYINT", length = 1)
//    @Column(name = "IsDone",columnDefinition = "BIT", length = 1)
//    @Type(type = "org.hibernate.type.NumericBooleanType")
    public Boolean Isdone;

    public Task() {
    }

    public Task(int id, String title, String description, Boolean isdone) {
        this.Id = id;
        this.Title = title;
        this.Description = description;
       this.Isdone = isdone;
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return Id;
    }

    public void setId(int id) {
        this.Id = id;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        this.Title = title;
    }
    
    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        this.Description = description;
    }
    
        
   public Boolean getIsdone() {
        return Isdone;
    }

    public void setIsdone(Boolean isdone) {
        this.Isdone = isdone;
    }

}