CREATE TABLE IF NOT EXISTS task (
     id INT NOT NULL AUTO_INCREMENT,
     description VARCHAR(255),
     title VARCHAR(255),
     isdone BOOLEAN,
     PRIMARY KEY (id)
);